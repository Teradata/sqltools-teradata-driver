"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
function ShowCommand(cur, s) {
    console.log("-- " + s);
    cur.execute(s);
    let n = 1;
    while (true) {
        console.log(`-- result set ${n}`);
        const rows = cur.fetchall();
        for (const row of rows) {
            const s = JSON.stringify(row).split("\\r").join("\n");
            console.log(s.slice(2, s.length - 2));
        }
        if (cur.nextset()) {
            n += 1;
        }
        else {
            break;
        }
    }
}
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
ShowCommand(cur, "show view DBC.DBCInfo");
console.log();
ShowCommand(cur, "show select * from DBC.DBCInfo");
cur.close();
con.close();
//# sourceMappingURL=ShowCommand.js.map