"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
function DisplayResults(cur) {
    while (true) {
        console.log(" === metadata ===");
        console.log("  cur.rowcount:", cur.rowcount);
        console.log("  cur.description:", cur.description);
        console.log(" === result ===");
        console.log(cur.fetchall());
        if (!cur.nextset()) {
            break;
        }
    }
}
function cur_execute(cur, sSQL, params) {
    console.log();
    console.log("cur.execute", sSQL, "bound values", params);
    cur.execute(sSQL, params);
    DisplayResults(cur);
}
function cur_callproc(cur, sProcName, params) {
    console.log();
    console.log("cur.callproc", sProcName, "bound values", params);
    cur.callproc(sProcName, params);
    DisplayResults(cur);
}
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("replace procedure examplestoredproc (in p1 integer, inout p2 integer) begin set p2 = p1 + p2 ; end ;");
try {
    cur_execute(cur, "{call examplestoredproc (3, 5)}");
    cur_execute(cur, "{call examplestoredproc (?, ?)}", [10, 7]);
    cur_callproc(cur, "examplestoredproc", [20, 4]);
    cur.execute("replace procedure examplestoredproc (out p1 varchar(100)) begin set p1 = 'foobar' ; end ;");
    cur_execute(cur, "{call examplestoredproc (?)}");
    cur.execute(`replace procedure examplestoredproc ()
                dynamic result sets 1
                begin
                    declare cur1 cursor with return for select * from dbc.dbcinfo order by 1 ;
                    open cur1 ;
                end ;`);
    cur_execute(cur, "{call examplestoredproc}");
    cur_callproc(cur, "examplestoredproc");
    cur.execute(`replace procedure examplestoredproc (in p1 integer, inout p2 integer, inout p3 integer)
            dynamic result sets 2
            begin
                declare cur1 cursor with return for select * from dbc.dbcinfo order by 1 ;
                declare cur2 cursor with return for select infodata, infokey from dbc.dbcinfo order by 1 ;
                open cur1 ;
                open cur2 ;
                set p2 = p1 + p2 ;
                set p3 = p1 * p3 ;
            end ;`);
    cur_execute(cur, "{call examplestoredproc (2, 1, 3)}");
    cur_execute(cur, "{call examplestoredproc (?, ?, ?)}", [3, 2, 4]);
    cur_callproc(cur, "examplestoredproc", [10, 3, 2]);
    cur.execute(`replace procedure examplestoredproc (in p1 integer, inout p2 integer, out p3 varchar(100))
                dynamic result sets 2
                begin
                    declare cur1 cursor with return for select * from dbc.dbcinfo order by 1 desc ;
                    declare cur2 cursor with return for select infodata, infokey from dbc.dbcinfo order by 1 ;
                    open cur1 ;
                    open cur2 ;
                    set p2 = p1 + p2 ;
                    set p3 = 'hello' ;
                end ;`);
    cur_execute(cur, "{call examplestoredproc (10, 5, ?)}");
    cur_execute(cur, "{call examplestoredproc (?, ?, ?)}", [20, 7]);
}
finally {
    cur.execute("drop procedure examplestoredproc");
}
cur.close();
con.close();
//# sourceMappingURL=StoredProc.js.map