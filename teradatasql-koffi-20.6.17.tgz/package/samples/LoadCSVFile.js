"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const sync_1 = require("csv-parse/sync");
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("create volatile table Airports (City varchar(100), Airport varchar(100), AirportCode varchar(10)) on commit preserve rows");
console.log("Slower approach - use a cvs module to parse data values from a CSV file");
const records = (0, sync_1.parse)(fs.readFileSync("airports.csv", { encoding: "utf-8" }));
cur.execute("insert into Airports (?, ?, ?)", records);
cur.execute("select AirportCode, Airport, City from Airports order by AirportCode");
console.log(cur.fetchall());
cur.execute("delete from Airports");
console.log("Faster approach - the driver loads data values from a CSV file");
cur.execute("{fn teradata_read_csv(airports.csv)}insert into Airports (?, ?, ?)");
cur.execute("select AirportCode, Airport, City from Airports order by AirportCode");
console.log(cur.fetchall());
cur.close();
con.close();
//# sourceMappingURL=LoadCSVFile.js.map