"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("CREATE TABLE MyTable (c1 CHAR(10), c2 CHAR(10))");
try {
    cur.execute("INSERT INTO MyTable VALUES ('a', 'b')");
    console.log("Original query that produces trailing space padding:");
    cur.execute("SELECT c1, c2 FROM MyTable");
    console.log(cur.fetchall());
    console.log("Modified query with either CAST or TRIM to avoid trailing space padding:");
    cur.execute("SELECT CAST(c1 AS VARCHAR(10)), TRIM(TRAILING FROM c2) FROM MyTable");
    console.log(cur.fetchall());
    cur.execute("CREATE VIEW MyView (c1, c2) AS SELECT CAST(c1 AS VARCHAR(10)), TRIM(TRAILING FROM c2) FROM MyTable");
    try {
        console.log("Or query view with CAST or TRIM to avoid trailing space padding:");
        cur.execute("SELECT c1, c2 FROM MyView");
        console.log(cur.fetchall());
    }
    finally {
        cur.execute("DROP VIEW MyView");
    }
}
finally {
    cur.execute("DROP TABLE MyTable");
}
cur.close();
con.close();
//# sourceMappingURL=CharPadding.js.map