"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
con.autocommit = false;
cur.execute("create volatile table voltab (c1 integer) on commit preserve rows");
con.commit();
cur.execute("insert into voltab values (1)");
con.commit();
cur.execute("insert into voltab values (2)");
con.rollback();
cur.execute("insert into voltab values (3)");
cur.execute("insert into voltab values (4)");
con.commit();
cur.execute("insert into voltab values (5)");
cur.execute("insert into voltab values (6)");
con.rollback();
cur.execute("select * from voltab order by 1");
con.commit();
const rows = cur.fetchall();
const anValues = [];
for (const row of rows) {
    anValues.push(row[0]);
}
console.log("Expected result set row values: [1,3,4]");
console.log(`Obtained result set row values: [${anValues}]`);
cur.close();
con.close();
//# sourceMappingURL=CommitRollback.js.map