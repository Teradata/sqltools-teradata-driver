"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
const sTableName = "batchinsperf";
const nRowsPerBatch = 10000;
const nBatchCount = 100;
try {
    cur.execute("drop table " + sTableName);
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
cur.execute("create table " + sTableName + " (c1 integer, c2 varchar(100), c3 integer, c4 varchar(100))");
try {
    let dStartTime1 = Date.now();
    for (let iBatch = 0; iBatch < nBatchCount; iBatch++) {
        const aaoBatch = [];
        for (let nRow = 1; nRow < nRowsPerBatch + 1; nRow++) {
            const nValue = iBatch * nRowsPerBatch + nRow;
            aaoBatch.push([nValue, "a" + nValue.toString(), -nValue, "b" + nValue.toString()]);
        }
        const dStartTime2 = Date.now();
        cur.execute("insert into " + sTableName + " values (?, ?, ?, ?)", aaoBatch);
        console.log(`Batch insert #${iBatch + 1} of ${nRowsPerBatch} rows took ${Date.now() - dStartTime2} ms"`);
    }
    let dTotalTime = Date.now() - dStartTime1;
    console.log(`Inserting ${nBatchCount} batches containing ${nBatchCount * nRowsPerBatch} total rows took ${dTotalTime} ms for ${((nBatchCount * nRowsPerBatch) / dTotalTime) * 1000} rows/sec throughput`);
    cur.execute("select count(*) from " + sTableName + " order by 1");
    const row = cur.fetchone();
    if (row) {
        console.log(`Table ${sTableName} contains ` + row[0] + " rows");
    }
}
finally {
    cur.execute("drop table " + sTableName);
}
cur.close();
con.close();
//# sourceMappingURL=BatchInsPerf.js.map