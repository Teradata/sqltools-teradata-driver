"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
async function worker() {
    let dStart = 0;
    let dElapsed = 0;
    try {
        dStart = Date.now();
        let sql = "select mysleep (10)";
        console.log(`worker() ${sql}`);
        await cur.executeAsync(sql);
        dElapsed = Date.now() - dStart;
    }
    catch (error) {
        dElapsed = Date.now() - dStart;
        console.log(`worker() received error: ${error.message.split("\n")[0]}`);
    }
    finally {
        console.log(`worker() completed in ${dElapsed / 1000} seconds`);
    }
}
async function main() {
    let sql = "drop function mysleep";
    console.log(`main() ${sql}`);
    cur.execute(sql, undefined, 5589);
    sql = "create function mysleep (integer) returns integer language c no sql parameter style sql external name 'CS!udfsleep!udfsleep.c!F!udfsleep'";
    console.log(`main() ${sql}`);
    cur.execute(sql);
    console.log("main() starting worker()");
    const result = worker();
    console.log("main() waiting for 5 seconds");
    const dStart = Date.now();
    await new Promise((resolve) => setTimeout(resolve, 5000));
    const dElapsed = Date.now() - dStart;
    console.log(`main() waited ${dElapsed / 1000} seconds`);
    try {
        console.log("main() calling cancel");
        con.cancel();
        console.log("main() completed cancel");
    }
    catch (error) {
        console.log(`main() ${error.message}`);
    }
    try {
        console.log("main() waiting for worker() to finish");
        await result;
        console.log("main() done waiting for worker() finishes");
    }
    catch (error) {
        console.log(`main() ${error.message}`);
    }
    finally {
        sql = "drop function mysleep";
        console.log(`main() ${sql}`);
        cur.execute(sql);
        cur.close();
        con.close();
    }
}
main();
//# sourceMappingURL=CancelSleep.js.map