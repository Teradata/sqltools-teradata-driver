"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const sync_1 = require("csv-parse/sync");
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
const cur2 = con.cursor();
const sTableName = "FastExportCSV";
let sRequest = "DROP TABLE " + sTableName;
try {
    console.log(sRequest);
    cur.execute(sRequest);
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
sRequest = "CREATE TABLE " + sTableName + " (c1 INTEGER NOT NULL, c2 VARCHAR(10))";
console.log(sRequest);
cur.execute(sRequest);
try {
    const sInsert = "INSERT INTO " + sTableName + " VALUES (?, ?)";
    console.log(sInsert);
    cur.execute(sInsert, [
        [1, null],
        [2, "abc"],
        [3, "def"],
        [4, "mno"],
        [5, null],
        [6, "pqr"],
        [7, "uvw"],
        [8, "xyz"],
        [9, null],
    ]);
    const sFileName = "dataJs.csv";
    const sSelect = "{fn teradata_try_fastexport}{fn teradata_write_csv(" + sFileName + ")}SELECT * FROM " + sTableName;
    console.log(sSelect);
    cur.execute(sSelect);
    try {
        console.log("Reading file", sFileName);
        const sRows = (0, sync_1.parse)(fs.readFileSync(sFileName, { encoding: "utf-8" }));
        console.log(sRows);
        sRequest = "{fn teradata_nativesql}{fn teradata_get_warnings}" + sSelect;
        console.log(sRequest);
        cur2.execute(sRequest);
        let rows = cur2.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        sRequest = "{fn teradata_nativesql}{fn teradata_get_errors}" + sSelect;
        console.log(sRequest);
        cur2.execute(sRequest);
        rows = cur2.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        sRequest = "{fn teradata_nativesql}{fn teradata_logon_sequence_number}" + sSelect;
        console.log(sRequest);
        cur2.execute(sRequest);
        rows = cur2.fetchall();
        for (const row of rows) {
            console.log(row);
        }
    }
    finally {
        fs.unlinkSync(sFileName);
    }
}
finally {
    sRequest = "DROP TABLE " + sTableName;
    console.log(sRequest);
    cur.execute(sRequest);
}
cur.close();
cur2.close();
con.close();
//# sourceMappingURL=FastExportCSV.js.map