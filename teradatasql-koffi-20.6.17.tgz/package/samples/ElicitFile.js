"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
console.log("Create function");
cur.execute("create function myudfinc(integer) returns integer language c no sql parameter style sql external name 'CS!udfinc!udfinc.c!F!udfinc'");
console.log("Execute function");
cur.execute("select myudfinc(1)");
const row = cur.fetchone();
if (row) {
    console.log("Function returned", row[0]);
}
console.log("Drop function");
cur.execute("drop function myudfinc");
cur.close();
con.close();
//# sourceMappingURL=ElicitFile.js.map