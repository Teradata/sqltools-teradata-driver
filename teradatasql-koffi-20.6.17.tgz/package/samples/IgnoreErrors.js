"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
console.log("Demonstrating how to ignore caught exceptions:");
console.log("drop user NonExistentUser");
try {
    cur.execute("drop user NonExistentUser");
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError && ex.message.includes("[Error 3802]")) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
console.log("drop view NonExistentView");
try {
    cur.execute("drop view NonExistentView");
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError && ex.message.includes("[Error 3807]")) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
console.log("drop macro NonExistentMacro");
try {
    cur.execute("drop macro NonExistentMacro");
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError && ex.message.includes("[Error 3824]")) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
console.log("drop table NonExistentTable");
try {
    cur.execute("drop table NonExistentTable");
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError && ex.message.includes("[Error 3807]")) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
console.log("drop database NonExistentDbase");
try {
    cur.execute("drop database NonExistentDbase");
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError && ex.message.includes("[Error 3802]")) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
console.log("drop procedure NonExistentProc");
try {
    cur.execute("drop procedure NonExistentProc");
}
catch (ex) {
    if (ex instanceof teradatasql_1.OperationalError && ex.message.includes("[Error 5495]")) {
        console.log("Ignoring", ex.message.split("\n")[0]);
    }
    else {
        throw ex;
    }
}
console.log();
console.log("Demonstrating how to ignore a single error:");
console.log("drop table NonExistentTable");
cur.execute("drop table NonExistentTable", undefined, 3807);
console.log();
console.log("Demonstrating how to ignore several different errors:");
const nonExistenceErrors = [
    3526,
    3802,
    3807,
    3824,
    3913,
    4322,
    5322,
    5495,
    5589,
    5620,
    5623,
    5653,
    5901,
    6808,
    6831,
    6834,
    6849,
    6863,
    6934,
    6938,
    7972,
    9213,
    9403,
];
console.log("drop user NonExistentUser");
cur.execute("drop user NonExistentUser", undefined, nonExistenceErrors);
console.log("drop view NonExistentView");
cur.execute("drop view NonExistentView", undefined, nonExistenceErrors);
console.log("drop macro NonExistentMacro");
cur.execute("drop macro NonExistentMacro", undefined, nonExistenceErrors);
console.log("drop table NonExistentTable");
cur.execute("drop table NonExistentTable", undefined, nonExistenceErrors);
console.log("drop database NonExistentDbase");
cur.execute("drop database NonExistentDbase", undefined, nonExistenceErrors);
console.log("drop procedure NonExistentProc");
cur.execute("drop procedure NonExistentProc", undefined, nonExistenceErrors);
cur.close();
con.close();
//# sourceMappingURL=IgnoreErrors.js.map