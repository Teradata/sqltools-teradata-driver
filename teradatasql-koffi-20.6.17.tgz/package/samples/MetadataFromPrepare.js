"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("{fn teradata_rpo(S)}{fn teradata_fake_result_sets}select * from dbc.dbcinfo where infokey=?");
const row = cur.fetchone();
if (row && cur.description) {
    console.log("SQL statement metadata from prepare operation:");
    console.log();
    for (let i = 0; i < cur.description.length; i++) {
        console.log(`   Column [${i}] ${cur.description[i][0].padEnd(18)} : ${row[i]}`);
    }
    console.log("Result set column metadata as JSON:");
    console.log(JSON.parse(row[7]));
    console.log();
    console.log("Parameter marker metadata as JSON:");
    console.log(JSON.parse(row[8]));
}
cur.close();
con.close();
//# sourceMappingURL=MetadataFromPrepare.js.map