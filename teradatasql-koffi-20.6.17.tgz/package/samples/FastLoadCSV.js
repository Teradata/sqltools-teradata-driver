"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const fs = __importStar(require("fs"));
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
const sTableName = "FastLoadCSV";
let sRequest = "DROP TABLE " + sTableName;
console.log(sRequest);
cur.execute(sRequest, undefined, 3807);
sRequest = "DROP TABLE " + sTableName + "_ERR_1";
console.log(sRequest);
cur.execute(sRequest, undefined, 3807);
sRequest = "DROP TABLE " + sTableName + "_ERR_2";
console.log(sRequest);
cur.execute(sRequest, undefined, 3807);
const records = ["c1,c2", "1,", "2,abc", "3,def", "4,mno", "5,", "6,pqr", "7,uvw", "8,xyz", "9,"];
console.log("records", records);
const csvFileName = "dataJs.csv";
for (const record of records) {
    fs.appendFileSync(csvFileName, record + "\n");
}
try {
    sRequest = "CREATE TABLE " + sTableName + " (c1 INTEGER NOT NULL, c2 VARCHAR(10))";
    console.log(sRequest);
    cur.execute(sRequest);
    try {
        console.log("con.autocommit = false");
        con.autocommit = false;
        try {
            const sInsert = "{fn teradata_require_fastload}{fn teradata_read_csv(" + csvFileName + ")}INSERT INTO " + sTableName + " (?, ?)";
            console.log(sInsert);
            cur.execute(sInsert);
            sRequest = "{fn teradata_nativesql}{fn teradata_get_warnings}" + sInsert;
            console.log(sRequest);
            cur.execute(sRequest);
            let rows = cur.fetchall();
            for (const row of rows) {
                console.log(row);
            }
            sRequest = "{fn teradata_nativesql}{fn teradata_get_errors}" + sInsert;
            console.log(sRequest);
            cur.execute(sRequest);
            rows = cur.fetchall();
            for (const row of rows) {
                console.log(row);
            }
            sRequest = "{fn teradata_nativesql}{fn teradata_logon_sequence_number}" + sInsert;
            console.log(sRequest);
            cur.execute(sRequest);
            rows = cur.fetchall();
            for (const row of rows) {
                console.log(row);
            }
            console.log("con.commit()");
            con.commit();
            sRequest = "{fn teradata_nativesql}{fn teradata_get_warnings}" + sInsert;
            console.log(sRequest);
            cur.execute(sRequest);
            rows = cur.fetchall();
            for (const row of rows) {
                console.log(row);
            }
            sRequest = "{fn teradata_nativesql}{fn teradata_get_errors}" + sInsert;
            console.log(sRequest);
            cur.execute(sRequest);
            rows = cur.fetchall();
            for (const row of rows) {
                console.log(row);
            }
        }
        finally {
            console.log("con.autocommit = true");
            con.autocommit = true;
        }
        sRequest = "SELECT * FROM " + sTableName + " ORDER BY 1";
        console.log(sRequest);
        cur.execute(sRequest);
        const rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
    }
    finally {
        sRequest = "DROP TABLE " + sTableName;
        console.log(sRequest);
        cur.execute(sRequest);
    }
}
finally {
    console.log(`delete ${csvFileName}`);
    fs.unlinkSync(csvFileName);
}
cur.close();
con.close();
//# sourceMappingURL=FastLoadCSV.js.map