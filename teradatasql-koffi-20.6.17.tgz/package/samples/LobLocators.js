"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
function byte(s, encoding) {
    return Uint8Array.from(Buffer.from(s, encoding));
}
function ReadLobValueFromLobLocator(con, abyLocator, sTypeName) {
    if (!(abyLocator instanceof Uint8Array)) {
        throw TypeError("abyLocator must be Unint8Array");
    }
    const cur = con.cursor();
    sSQL = "{fn teradata_parameter(1," + sTypeName + ")}select ?";
    console.log(sSQL);
    cur.execute(sSQL, [abyLocator]);
    const row = cur.fetchone();
    let result = null;
    if (row) {
        result = row[0];
    }
    cur.close();
    return result;
}
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
let sSQL = "create volatile table voltab (c1 integer, c2 blob, c3 clob, c4 xml, c5 st_geometry, c6 json) on commit preserve rows";
console.log(sSQL);
cur.execute(sSQL);
const sXML = '<?xml version="1.0" encoding="UTF-8"?><foo>bar</foo>';
const sJSON = '{"foo":"bar"}';
sSQL =
    "insert into voltab values (1, '" + Buffer.from(byte("ABC")).toString("hex") + "'xbv, 'clobval', '" + sXML + "', 'point(1 2)', '" + sJSON + "')";
console.log(sSQL);
cur.execute(sSQL);
sSQL = "{fn teradata_lobselect(S)}{fn teradata_fake_result_sets}select * from voltab order by 1";
console.log(sSQL);
cur.execute(sSQL);
const aoFakeResultSetRow = cur.fetchone();
if (aoFakeResultSetRow) {
    const sResultSetColumnMetadataJSON = aoFakeResultSetRow[7].toString();
    const amapResultSetColumnMetadata = JSON.parse(sResultSetColumnMetadataJSON);
    cur.nextset();
    const aoRealResultSetRow = cur.fetchone();
    if (aoRealResultSetRow) {
        for (let iColumn = 0; iColumn < aoRealResultSetRow.length; iColumn++) {
            let oValue = aoRealResultSetRow[iColumn];
            const sTypeName = amapResultSetColumnMetadata[iColumn]["TypeName"];
            if (sTypeName.startsWith("LOCATOR(")) {
                oValue = ReadLobValueFromLobLocator(con, oValue, sTypeName);
            }
            console.log(`Column ${iColumn + 1} ${sTypeName} value: ${oValue}`);
        }
    }
}
cur.close();
con.close();
//# sourceMappingURL=LobLocators.js.map