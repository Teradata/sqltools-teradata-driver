"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
const sTableName = "FastLoadBatch";
let sRequest = "DROP TABLE " + sTableName;
console.log(sRequest);
cur.execute(sRequest, undefined, 3807);
sRequest = "CREATE TABLE " + sTableName + " (c1 INTEGER NOT NULL, c2 VARCHAR(10))";
console.log(sRequest);
cur.execute(sRequest);
try {
    console.log("con.autocommit = false");
    con.autocommit = false;
    try {
        let aaoValues = [
            [
                1,
                null,
            ],
            [
                2,
                "abc",
            ],
            [
                3,
                "def",
            ],
        ];
        const sInsert = "{fn teradata_try_fastload}INSERT INTO " + sTableName + " (?, ?)";
        console.log(sInsert);
        cur.execute(sInsert, aaoValues);
        sRequest = "{fn teradata_nativesql}{fn teradata_get_warnings}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        let rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        sRequest = "{fn teradata_nativesql}{fn teradata_get_errors}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        sRequest = "{fn teradata_nativesql}{fn teradata_logon_sequence_number}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        aaoValues = [
            [
                4,
                "mno",
            ],
            [
                5,
                null,
            ],
            [
                6,
                "pqr",
            ],
        ];
        console.log(sInsert);
        cur.execute(sInsert, aaoValues);
        sRequest = "{fn teradata_nativesql}{fn teradata_get_warnings}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        sRequest = "{fn teradata_nativesql}{fn teradata_get_errors}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        aaoValues = [
            [
                7,
                "uvw",
            ],
            [
                8,
                "xyz",
            ],
            [
                9,
                null,
            ],
        ];
        console.log(sInsert);
        cur.execute(sInsert, aaoValues);
        sRequest = "{fn teradata_nativesql}{fn teradata_get_warnings}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        sRequest = "{fn teradata_nativesql}{fn teradata_get_errors}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        console.log("con.commit()");
        con.commit();
        sRequest = "{fn teradata_nativesql}{fn teradata_get_warnings}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
        sRequest = "{fn teradata_nativesql}{fn teradata_get_errors}" + sInsert;
        console.log(sRequest);
        cur.execute(sRequest);
        rows = cur.fetchall();
        for (const row of rows) {
            console.log(row);
        }
    }
    finally {
        console.log("con.autocommit = true");
        con.autocommit = true;
    }
    sRequest = "SELECT * FROM " + sTableName + " ORDER BY 1";
    console.log(sRequest);
    cur.execute(sRequest);
    const rows = cur.fetchall();
    for (const row of rows) {
        console.log(row);
    }
}
finally {
    sRequest = "DROP TABLE " + sTableName;
    console.log(sRequest);
    cur.execute(sRequest);
}
cur.close();
con.close();
//# sourceMappingURL=FastLoadBatch.js.map