"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
if (process.argv.length != 6) {
    console.log("Parameters: Host User Password SQL");
    process.exit(1);
}
const sHost = process.argv[2];
const sUser = process.argv[3];
const sPassword = process.argv[4];
const sSQL = process.argv[5];
let con = new teradatasql_1.TeradataConnection();
try {
    con.connect({ host: sHost, user: sUser, password: sPassword });
    let cur = con.cursor();
    try {
        console.log(`Executing ${sSQL}`);
        cur.execute(sSQL);
        for (let nResult = 1;; nResult++) {
            const rows = cur.fetchall();
            for (let iRow = 0; iRow < rows.length; iRow++) {
                const row = rows[iRow];
                for (let iColumn = 0; row != null && iColumn < row.length; iColumn++) {
                    let oValue = row[iColumn];
                    let sType = typeof oValue;
                    if (sType === "number") {
                        const n = Number(cur.description[iColumn][5]);
                        if (n > 0) {
                            oValue = oValue.toFixed(n);
                        }
                    }
                    else if (sType === "object") {
                        sType = oValue.constructor.name;
                    }
                    if (sType === "Date") {
                        oValue = "toISOString: " + oValue.toISOString() + " toString: " + oValue.toString();
                    }
                    if (sType === "Uint8Array") {
                        oValue = Buffer.from(oValue).toString("hex");
                    }
                    console.log(`Result ${nResult} Row ${iRow + 1} Column ${iColumn + 1} ${cur.description[iColumn][0]} ${sType} = ${oValue}`);
                }
            }
            if (!cur.nextset()) {
                break;
            }
        }
    }
    finally {
        cur.close();
    }
}
finally {
    con.close();
}
//# sourceMappingURL=ExecuteRequest.js.map