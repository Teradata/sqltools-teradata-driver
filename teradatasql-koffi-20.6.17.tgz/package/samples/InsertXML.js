"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("create volatile table voltab (c1 integer, c2 xml) on commit preserve rows");
cur.execute("{fn teradata_parameter(2,XML)}insert into voltab values (?, ?)", [
    [1, "<hello>world</hello>"],
    [2, "<hello>moon</hello>"],
]);
cur.execute("{fn teradata_fake_result_sets}select * from voltab order by 1");
const asTypeNames = [];
let row = cur.fetchone();
if (row) {
    const json = JSON.parse(row[7].toString());
    for (const elem of json) {
        for (const k in elem) {
            if (k === "TypeName") {
                asTypeNames.push(elem[k]);
            }
        }
    }
}
cur.nextset();
const rows = cur.fetchall();
for (let nRow = 0; nRow < rows.length; nRow++) {
    row = rows[nRow];
    if (row && cur.description) {
        for (let iColumn = 0; iColumn < row.length; iColumn++) {
            console.log(`Row ${nRow + 1} Column ${cur.description[iColumn][0]} ${asTypeNames[iColumn].padEnd(7)} ${row[iColumn]}`);
        }
    }
}
cur.close();
con.close();
//# sourceMappingURL=InsertXML.js.map