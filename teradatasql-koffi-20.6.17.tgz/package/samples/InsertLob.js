"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
function byte(s, encoding) {
    return Uint8Array.from(Buffer.from(s, encoding));
}
function FormatValue(oValue) {
    let s;
    if (typeof oValue === "string") {
        s = oValue;
        if (s.length > 20) {
            s = s.slice(0, 20) + " ...";
        }
        return s + ` (len=${oValue.length})`;
    }
    else if (oValue instanceof Uint8Array) {
        s = Buffer.from(oValue).toString();
        if (s.length > 20) {
            s = s.slice(0, 20) + " ...";
        }
        return `byte('${s}')` + ` (len=${oValue.length})`;
    }
    else {
        return oValue;
    }
}
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please", log: "8" });
const cur = con.cursor();
let sSQL = "create volatile table voltab (c1 integer, c2 blob, c3 clob) on commit preserve rows";
console.log(sSQL);
cur.execute(sSQL);
const abySmallBlob = byte("abc");
const abyLargeBlob = byte("ABC".repeat(75000));
const sSmallClob = "xyz";
const sLargeClob = "XYZ".repeat(25000);
sSQL = "insert into voltab values (?, ?, ?)";
console.log(sSQL);
cur.execute(sSQL, [1, abySmallBlob, sSmallClob]);
console.log(sSQL);
cur.execute(sSQL, [2, abyLargeBlob, sLargeClob]);
sSQL = "select * from voltab order by 1";
console.log(sSQL);
cur.execute(sSQL);
let nRow = 0;
let row = null;
while (true) {
    row = cur.fetchone();
    if (!row) {
        break;
    }
    nRow += 1;
    if (cur.description) {
        for (let iColumn = 0; iColumn < row.length; iColumn++) {
            console.log(`Row ${nRow} Column ${iColumn + 1} "${cur.description[iColumn][0]}" = ${FormatValue(row[iColumn])}`);
        }
    }
}
console.log(`Fetched ${nRow} rows`);
cur.close();
con.close();
//# sourceMappingURL=InsertLob.js.map