"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("create volatile table voltab (c1 integer, c2 varchar(100)) on commit preserve rows");
cur.execute("insert into voltab (?, ?)", [
    [1, "abc"],
    [2, "def"],
    [3, "ghi"],
]);
cur.execute("select * from voltab order by 1");
console.log(cur.fetchall());
cur.close();
con.close();
//# sourceMappingURL=BatchInsert.js.map