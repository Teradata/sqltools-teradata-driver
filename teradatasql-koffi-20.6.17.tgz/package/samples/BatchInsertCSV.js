"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const sync_1 = require("csv-stringify/sync");
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("create volatile table voltab (c1 integer, c2 varchar(100)) on commit preserve rows");
const records = [
    ["c1", "c2"],
    ["1", ""],
    ["2", "abc"],
    ["3", "def"],
    ["4", "mno"],
    ["5", ""],
    ["6", "pqr"],
    ["7", "uvw"],
    ["8", "xyz"],
    ["9", ""],
];
const sFileName = "CSVBatchInsertData_js";
fs.writeFileSync(sFileName, (0, sync_1.stringify)(records));
try {
    console.log("Inserting data");
    cur.execute(`{fn teradata_read_csv(${sFileName})} insert into voltab (?, ?)`);
}
finally {
    fs.unlinkSync(sFileName);
}
cur.execute("select * from voltab order by 1");
console.log(cur.fetchall());
cur.close();
con.close();
//# sourceMappingURL=BatchInsertCSV.js.map