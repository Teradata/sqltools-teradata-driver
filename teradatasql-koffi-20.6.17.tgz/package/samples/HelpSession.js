"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("help session");
const row = cur.fetchone();
if (row) {
    for (let i = 0; i < row.length; i++) {
        if (cur.description) {
            console.log(`${cur.description[i][0].padEnd(40)}, ${row[i]}`);
        }
    }
}
cur.close();
con.close();
//# sourceMappingURL=HelpSession.js.map