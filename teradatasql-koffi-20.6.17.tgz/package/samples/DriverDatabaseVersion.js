"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const teradatasql_1 = require("teradatasql");
const con = new teradatasql_1.TeradataConnection();
con.connect({ host: "whomooz", user: "guest", password: "please" });
const cur = con.cursor();
cur.execute("{fn teradata_nativesql}Driver version {fn teradata_driver_version}  Database version {fn teradata_database_version}");
const row = cur.fetchone();
if (row) {
    console.log(row[0]);
}
cur.close();
con.close();
//# sourceMappingURL=DriverDatabaseVersion.js.map