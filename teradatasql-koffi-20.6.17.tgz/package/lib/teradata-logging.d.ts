declare global {
    interface Date {
        timestampNow(): string;
    }
    interface BigInt {
        toJSON: () => string;
    }
}
export declare class TeradataLogging {
    private bTracelog;
    private bDebuglog;
    private bTiminglog;
    private id;
    constructor(logLevel?: number);
    get bTraceLog(): boolean;
    get bDebugLog(): boolean;
    get bTimingLog(): boolean;
    traceLog(message: any, jsonStringify?: boolean): void;
    debugLog(message: any, jsonStringify?: boolean): void;
    timingLog(message: any, jsonStringify?: boolean): void;
    private logMsg;
}
//# sourceMappingURL=teradata-logging.d.ts.map