import { ITDConnParams, TeradataConnection } from "./teradata-connection";
export { ITDConnParams, TeradataConnection };
export { BINARY, DATE, NUMBER, STRING, TeradataCursor } from "./teradata-cursor";
export { TeradataLogging } from "./teradata-logging";
export { InterfaceError, DatabaseError, DataError, IntegrityError, OperationalError, ProgrammingError } from "./teradata-exceptions";
export declare const apilevel: string;
export declare const threadsafety: number;
export declare const paramstyle: string;
export declare function date(year: number, month: number, day: number): string;
export declare function dateFromTicks(seconds: number): string;
export declare function timestamp(year: number, month: number, day: number, hour: number, minute: number, second: number): Date;
export declare function timestampFromTicks(seconds: number): Date;
export declare function connect(objConParams?: ITDConnParams, strConParams?: string): TeradataConnection;
//# sourceMappingURL=index.d.ts.map