export declare class InterfaceError extends Error {
    constructor(message?: string);
}
export declare class DatabaseError extends Error {
    constructor(message?: string);
}
export declare class DataError extends DatabaseError {
    constructor(message?: string);
}
export declare class IntegrityError extends DatabaseError {
    constructor(message?: string);
}
export declare class OperationalError extends DatabaseError {
    constructor(message?: string);
}
export declare class ProgrammingError extends DatabaseError {
    constructor(message?: string);
}
//# sourceMappingURL=teradata-exceptions.d.ts.map